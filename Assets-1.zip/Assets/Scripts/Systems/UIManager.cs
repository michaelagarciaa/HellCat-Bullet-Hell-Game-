using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;    
using TMPro;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    [Header("HUD")]
    [SerializeField] private GameObject hudRoot;     
    [SerializeField] private TMP_Text scoreText;
    [SerializeField] private TMP_Text waveText;
    [SerializeField] private TMP_Text hpText;
    [SerializeField] private TMP_Text bombText;
    [SerializeField] private TMP_Text timerText;    

    [Header("Panels")]
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private GameObject gameOverPanel;
    [SerializeField] private TMP_Text gameOverStats;

    [Header("Scene Auto-Toggle")]
    [SerializeField] private bool autoToggleHudByScene = true;
    [SerializeField] private string gameplaySceneName = "MainLevel";

    [Header("Damage Flash")]
    [SerializeField] private Image damageFlashImage;           
    [SerializeField] private Color flashColor = new Color(1f, 0f, 0f, 0.6f);
    [SerializeField] private float flashFadeDuration = 0.25f;  
    private Coroutine flashRoutine;

    // Timer
    private float elapsedTime = 0f;
    private bool timerRunning = false;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        
    }

    void OnEnable()
    {
        if (autoToggleHudByScene)
            SceneManager.sceneLoaded += OnSceneLoaded;
    }

    void OnDisable()
    {
        if (autoToggleHudByScene)
            SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    void Start()
    {
        if (pausePanel)    pausePanel.SetActive(false);
        if (gameOverPanel) gameOverPanel.SetActive(false);

        if (damageFlashImage)
        {
            damageFlashImage.raycastTarget = false;
            SetDamageFlashAlpha(0f);
        }

        if (autoToggleHudByScene)
        {
            var s = SceneManager.GetActiveScene();
            bool inGameplay = s.name == gameplaySceneName;
            ShowHUD(inGameplay);
            ResetTimer();
            if (inGameplay) StartTimer(); else StopTimer();
        }
        else
        {
            ResetTimer();
        }

        UpdateTimerUI();
    }

    void Update()
    {
        if (timerRunning)
        {
            elapsedTime += Time.deltaTime; 
            UpdateTimerUI();
        }
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (pausePanel)    pausePanel.SetActive(false);
        if (gameOverPanel) gameOverPanel.SetActive(false);
        if (damageFlashImage) SetDamageFlashAlpha(0f);

        bool inGameplay = scene.name == gameplaySceneName;
        ShowHUD(inGameplay);

        ResetTimer();
        if (inGameplay) StartTimer(); else StopTimer();
    }

    

    public void ShowHUD(bool show)
    {
        if (hudRoot) hudRoot.SetActive(show);
    }

    public void TogglePauseUI(bool show)
    {
        if (pausePanel) pausePanel.SetActive(show);
    }

    public void ShowGameOver(int score, int wave)
    {
        if (gameOverPanel) gameOverPanel.SetActive(true);
        StopTimer(); // freeze final time

        if (gameOverStats)
        {
            string timeStr = GetElapsedTimeFormatted();
            gameOverStats.text = $"Final Score: {score}\nWaves Survived: {wave}\nTime: {timeStr}";
        }
    }

    public void UpdateScore(int v)       { if (scoreText) scoreText.text = $"Score: {v}"; }
    public void UpdateWave(int v)        { if (waveText)  waveText.text  = $"Wave: {v}"; }
    public void UpdateHP(int c, int m)   { if (hpText)    hpText.text    = $"HP: {c}/{m}"; }
    public void UpdateBombs(int c, int m){ if (bombText)  bombText.text  = $"Bombs: {c}/{m}"; }

    //Timer controls 
    public void StartTimer()  { timerRunning = true; }
    public void StopTimer()   { timerRunning = false; }
    public void ResetTimer()  { elapsedTime = 0f; UpdateTimerUI(); }
    public float GetElapsedTime() => elapsedTime;
    public string GetElapsedTimeFormatted()
    {
        int minutes = Mathf.FloorToInt(elapsedTime / 60f);
        int seconds = Mathf.FloorToInt(elapsedTime % 60f);
        return $"{minutes:00}:{seconds:00}";
    }

    void UpdateTimerUI()
    {
        if (timerText) timerText.text = GetElapsedTimeFormatted();
    }

    //Damage flash
    public void FlashDamage()
    {
        if (damageFlashImage == null) return;

        
        if (flashRoutine != null) StopCoroutine(flashRoutine);
        flashRoutine = StartCoroutine(DamageFlashRoutine());
    }

    System.Collections.IEnumerator DamageFlashRoutine()
    {
        
        damageFlashImage.color = flashColor;

        float t = 0f;
        float dur = Mathf.Max(0.01f, flashFadeDuration);

        
        while (t < dur)
        {
            t += Time.unscaledDeltaTime;
            float a = Mathf.Lerp(flashColor.a, 0f, t / dur);
            SetDamageFlashAlpha(a);
            yield return null;
        }

        SetDamageFlashAlpha(0f);
        flashRoutine = null;
    }

    void SetDamageFlashAlpha(float a)
    {
        var c = flashColor;
        c.a = Mathf.Clamp01(a);
        damageFlashImage.color = c;
    }
}
