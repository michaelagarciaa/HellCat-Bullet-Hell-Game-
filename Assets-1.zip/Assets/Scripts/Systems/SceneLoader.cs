using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
    [Header("Scene Names")]
    [Tooltip("Exact name of your gameplay scene (match Build Settings).")]
    public string gameSceneName = "MainLevel";
    [Tooltip("Exact name of your title scene (match Build Settings).")]
    public string titleSceneName = "MainMenu";

    public void LoadGame()
    {
        // Reset run state before loading game
        if (GameManager.Instance != null)
            GameManager.Instance.ResetRun();

        SceneManager.LoadScene(gameSceneName);
    }

    public void LoadTitle()
    {
        
        Time.timeScale = 1f;

        if (GameManager.Instance != null)
            GameManager.Instance.ResetRun();

        SceneManager.LoadScene(titleSceneName);
    }

    public void ReloadCurrent()
    {
        if (GameManager.Instance != null)
            GameManager.Instance.ResetRun();

        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void Quit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
