using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("UI")]
    public GameObject gameOverPanel;   

    [Header("Options")]
    public bool pauseOnGameOver = true;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;

        Time.timeScale = 1f;
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
    }

    public void GameOver()
    {
        
        UIManager.Instance?.ShowGameOver(score: 0, wave: 0);

        if (gameOverPanel != null) gameOverPanel.SetActive(true); 

        if (pauseOnGameOver) Time.timeScale = 0f;
        Debug.Log("GAME OVER");
    }

    public void ResetRun()
    {
        Time.timeScale = 1f;

        // Hide any leftover panels and reset timer
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
        UIManager.Instance?.ResetTimer();
    }
}
