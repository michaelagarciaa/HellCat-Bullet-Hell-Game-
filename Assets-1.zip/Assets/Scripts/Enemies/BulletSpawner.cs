using UnityEngine;

public class BulletSpawner : MonoBehaviour
{
    [Header("Setup")]
    public GameObject bulletPrefab;
    public Transform target; 

    [Header("Firing Settings")]
    public float fireInterval = 2f;        
    [Range(0f, 1f)] public float shootChance = 0.3f; 
    public float bulletSpeed = 6f;

    private float nextFireTime;

    void Start()
    {
        if (target == null)
            target = GameObject.FindGameObjectWithTag("Player")?.transform;

        
        nextFireTime = Time.time + Random.Range(0f, fireInterval);
    }

    void Update()
    {
        if (Time.time >= nextFireTime && target != null)
        {
            nextFireTime = Time.time + fireInterval;

            if (Random.value <= shootChance)
                ShootAtPlayer();
        }
    }

    void ShootAtPlayer()
    {
        Vector2 dir = (target.position - transform.position).normalized;

        GameObject bulletObj = Instantiate(bulletPrefab, transform.position, Quaternion.identity);

        Rigidbody2D rb = bulletObj.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.linearVelocity = dir * bulletSpeed;
        }
    }
}
