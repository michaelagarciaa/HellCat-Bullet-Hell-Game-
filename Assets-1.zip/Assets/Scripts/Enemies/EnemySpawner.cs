using UnityEngine;
using System.Collections;

public class EnemySpawner : MonoBehaviour
{
    [Header("Prefab")]
    [Tooltip("Prefab with Enemy.cs + Rigidbody2D + Collider2D")]
    public GameObject enemyPrefab;

    [Header("Spawn Timing (ramps over time)")]
    [Tooltip("Initial minimum seconds between spawns at t=0")]
    public float startIntervalMin = 0.8f;
    [Tooltip("Initial maximum seconds between spawns at t=0")]
    public float startIntervalMax = 1.4f;

    [Tooltip("Final minimum seconds between spawns when ramp completes")]
    public float endIntervalMin = 0.15f;
    [Tooltip("Final maximum seconds between spawns when ramp completes")]
    public float endIntervalMax = 0.35f;

    [Tooltip("Seconds until difficulty fully ramps (use 0 to disable ramp)")]
    public float rampDuration = 90f;

    [Header("Enemy Speed (optional ramp)")]
    [Tooltip("Enemy speed range at t=0")]
    public float startSpeedMin = 2f;
    public float startSpeedMax = 4f;
    [Tooltip("Enemy speed range when ramp completes")]
    public float endSpeedMin = 4f;
    public float endSpeedMax = 7f;

    [Header("Spawn Outside Screen")]
    [Tooltip("How far outside the view to spawn, as a fraction of screen size")]
    public float edgePadding = 0.1f;

    private Camera cam;

    void Awake()
    {
        cam = Camera.main;
        if (cam == null) Debug.LogError("EnemySpawner: No Camera.main found.");
    }

    void OnEnable() => StartCoroutine(SpawnLoop());
    void OnDisable() => StopAllCoroutines();

    IEnumerator SpawnLoop()
    {
        if (enemyPrefab == null)
        {
            Debug.LogError("EnemySpawner: enemyPrefab not assigned.");
            yield break;
        }

        while (true)
        {
            
            float t = rampDuration > 0f ? Mathf.Clamp01(Time.timeSinceLevelLoad / rampDuration) : 1f;

            
            float curMin = Mathf.Lerp(startIntervalMin, endIntervalMin, t);
            float curMax = Mathf.Lerp(startIntervalMax, endIntervalMax, t);
            if (curMax < curMin) curMax = curMin; // safety

            yield return new WaitForSeconds(Random.Range(curMin, curMax));

            // Spawn
            Vector3 spawnPos = GetRandomEdgePosition(cam, edgePadding);
            var enemyObj = Instantiate(enemyPrefab, spawnPos, Quaternion.identity);

            
            Vector2 dirToCenter = ((Vector2)cam.transform.position - (Vector2)spawnPos).normalized;
            Vector2 jitter = Random.insideUnitCircle * 0.5f;
            Vector2 finalDir = (dirToCenter + jitter).normalized;

            // Current speed range
            float speedMin = Mathf.Lerp(startSpeedMin, endSpeedMin, t);
            float speedMax = Mathf.Lerp(startSpeedMax, endSpeedMax, t);
            if (speedMax < speedMin) speedMax = speedMin; // safety
            float speed = Random.Range(speedMin, speedMax);

            // Initialize movement 
            var enemy = enemyObj.GetComponent<Enemy>();
            if (enemy != null)
            {
                enemy.Init(finalDir, speed);
            }
            else
            {
                // Fallback if Enemy not present 
                var rb = enemyObj.GetComponent<Rigidbody2D>();
                if (rb != null) rb.linearVelocity = finalDir * speed;
            }
        }
    }

    // Spawns just outside one of the four edges
    Vector3 GetRandomEdgePosition(Camera c, float paddingFactor)
    {
        int edge = Random.Range(0, 4); 
        float t = Random.value;

        Vector3 vp = edge switch
        {
            0 => new Vector3(0f, t, 0f),
            1 => new Vector3(1f, t, 0f),
            2 => new Vector3(t, 0f, 0f),
            _ => new Vector3(t, 1f, 0f),
        };

        Vector3 world = c.ViewportToWorldPoint(new Vector3(vp.x, vp.y, Mathf.Abs(c.transform.position.z)));
        world.z = 0f;

        Vector2 normal = edge switch
        {
            0 => Vector2.left,
            1 => Vector2.right,
            2 => Vector2.down,
            _ => Vector2.up
        };

        float padX = c.orthographic ? c.orthographicSize * c.aspect * paddingFactor : paddingFactor;
        float padY = c.orthographic ? c.orthographicSize * paddingFactor : paddingFactor;

        world += new Vector3(normal.x * padX, normal.y * padY, 0f);
        return world;
    }
}
