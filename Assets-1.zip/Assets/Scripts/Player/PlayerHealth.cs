using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    [Header("Health Settings")]
    public int maxHP = 3;
    public float invulnerabilityTime = 0.5f; // i-frames after getting hit

    private int currentHP;
    private float lastHitTime;

    void Awake()
    {
        currentHP = maxHP;
        UIManager.Instance?.UpdateHP(currentHP, maxHP);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Enemy"))
        {
            TakeDamage(1);
        }
    }

    public void TakeDamage(int amount)
    {
        if (Time.time - lastHitTime < invulnerabilityTime) return;

        lastHitTime = Time.time;
        currentHP = Mathf.Max(0, currentHP - amount);

        // UI feedback
        UIManager.Instance?.UpdateHP(currentHP, maxHP);
        UIManager.Instance?.FlashDamage();

        if (currentHP <= 0)
        {
            GameManager.Instance?.GameOver();
        }
    }

    public void Heal(int amount)
    {
        currentHP = Mathf.Min(maxHP, currentHP + amount);
        UIManager.Instance?.UpdateHP(currentHP, maxHP);
    }

    public int GetCurrentHP() => currentHP;
}
